<?php
$host="localhost";
$username="root";
$password="";
$database="cardb";

$con=mysqli_connect($host,$username,$password,$database) or die("Connection Fail");
//$con=mysqli_select_db($database) or die("Connection Fail");
?>